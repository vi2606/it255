/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex2;

import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 *
 * @author vi420
 */
public class Test {

    public static void main(String[] args) {
        new Test();
        get();
        get("3");
    }

    public Test() {
        User_post user_post = new User_post("NewName", "newjob");

        /*   This is POST part*/
        try {
            URL url = new URL("https://reqres.in/api/users");

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true);
//            conn.setDoInput(true);
//            conn.setUseCaches(false);
//            conn.setConnectTimeout(1000 * 5);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (X11; Linux x86_64; rv:12.0) Gecko/20100101 Firefox/12.0");
            conn.setRequestProperty("content-type", "application/json;  charset=utf-8");
            conn.setRequestProperty("Accept-Language", "en-US,en;q=0.5");

//            if (conn.getResponseCode() != 201) {
//                throw new RuntimeException("Greška : HTTP error: "
//                        + conn.getResponseCode());
//            }

            PrintWriter pw = new PrintWriter(conn.getOutputStream());
            pw.print(new Gson().toJson(user_post));
            pw.close();
            pw.flush();

            BufferedReader br = new BufferedReader(new InputStreamReader(
                    (conn.getInputStream())));
            String output;
            System.out.println("POST: Output from Server : ");
            while ((output = br.readLine()) != null) {
                System.out.println(output);
            }
            conn.disconnect();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
        /* ^^^^^  This is POST part*/

    
   

    public static void get() {
        String output;
        String json = "";
        try {
            URL url = new URL("https://reqres.in/api/users");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("User-Agent", "Mozilla/5.0");

            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP error code :" + conn.getResponseCode());
            }
            BufferedReader br = new BufferedReader(new InputStreamReader(
                    (conn.getInputStream())));
            System.out.println("\nGET: Output from Server for all users.... ");
            while ((output = br.readLine()) != null) {
//                System.out.println(output);
                json += output;
            }
            conn.disconnect();
            Gson gson = new Gson();

//            System.out.println(json);
            EntryArray user_get = gson.fromJson(json, EntryArray.class);

            for (User usr : user_get.getData()) {
                System.out.println("Ime " + usr.getId() + " " + usr.getFirst_name() + " " + usr.getLast_name());
                System.out.println("Avatar: " + usr.getAvatar());
            }

//            System.out.println("User: id:" + user_get.getData().getId() + " " + user_get.getData().getFirst_name() + " " + user_get.getData().getLast_name());
//            System.out.println("Avatar URL: " + user_get.getData().getAvatar());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
     public static void get(String id) {
        String output;
        String json = "";
        try {
            if (id.equals("all")) {

                URL url = new URL("https://reqres.in/api/users");
            }

            URL url = new URL("https://reqres.in/api/users/" + id);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("User-Agent", "Mozilla/5.0");

            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP error code :" + conn.getResponseCode());
            }
            BufferedReader br = new BufferedReader(new InputStreamReader(
                    (conn.getInputStream())));
            System.out.println("\nGET: Output from Server for user " + id + ".... ");
            while ((output = br.readLine()) != null) {
//                System.out.println(output);
                json += output;
            }
            conn.disconnect();
            Gson gson = new Gson();

//            System.out.println(json);
            Entry user_get = gson.fromJson(json, Entry.class);

//            System.out.println(user_get);
            System.out.println("User: id:" + user_get.getData().getId() + " " + user_get.getData().getFirst_name() + " " + user_get.getData().getLast_name());
            System.out.println("Avatar URL: " + user_get.getData().getAvatar());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
